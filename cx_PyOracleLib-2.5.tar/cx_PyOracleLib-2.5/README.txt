cx_PyOracleLib
--------------
This project contains a number of Python modules that are used by a number of
projects, in particular the cx_OracleTools project, and as such they are
handled independently, rather than bundled with a distribution of the
dependent project.

It is released under a free software license, see LICENSE.txt for more
details.

